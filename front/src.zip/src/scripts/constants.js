// Количество показываемых карточек при первом рендере
export const COUNT_SHOW_CARDS_CLICK = 6;

export const ERROR_SERVER = 'Ошибка сервера, попробуйте позже!';
export const NO_PRODUCTS_IN_THIS_CATEGORY = 'Товаров в этой категории нет!';
export const PRODUCT_INFORMATION_NOT_FOUND = 'Информация о товаре не найдена!';
export const NO_ITEMS_CART = 'В корзине нет товаров!';




